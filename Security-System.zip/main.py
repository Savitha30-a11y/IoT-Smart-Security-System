import cv2
import requests
import datetime
import os
import time

BLYNK_AUTH = "K8phE97o22-YpuBcruSSOT3IAzsG5hdD"
BASE_URL = "https://blynk.cloud/external/api"
BLYNK_LED_ON = f"{BASE_URL}/update?token={BLYNK_AUTH}&V1=1"
BLYNK_LED_OFF = f"{BASE_URL}/update?token={BLYNK_AUTH}&V1=0"
BLYNK_NOTIFY = f"{BASE_URL}/notify?token={BLYNK_AUTH}&message=Motion+Detected+on+Camera!"

SAVE_FOLDER = "captured_images"
os.makedirs(SAVE_FOLDER, exist_ok=True)

cap = cv2.VideoCapture(0)
time.sleep(2)

print("🔒 Security System Active. Monitoring for motion...")

first_frame = None

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("⚠️ Camera error! Exiting...")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)

        if first_frame is None:
            first_frame = gray
            continue

        delta = cv2.absdiff(first_frame, gray)
        thresh = cv2.threshold(delta, 25, 255, cv2.THRESH_BINARY)[1]
        thresh = cv2.dilate(thresh, None, iterations=2)

        contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        motion_detected = False

        for contour in contours:
            if cv2.contourArea(contour) < 10000:
                continue
            motion_detected = True
            (x, y, w, h) = cv2.boundingRect(contour)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        if motion_detected:
            print("⚠️ Motion Detected! Sending alert to Blynk...")
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            filename = os.path.join(SAVE_FOLDER, f"motion_{timestamp}.jpg")
            cv2.imwrite(filename, frame)
            print(f"📸 Image saved as {filename}")

            try:
                requests.get(BLYNK_LED_ON, timeout=5)
                requests.get(BLYNK_NOTIFY, timeout=5)
                print("✅ Blynk Alert Sent (LED ON + Notification)")
            except Exception as e:
                print("❌ Blynk Error:", e)

            time.sleep(5)
        else:
            try:
                requests.get(BLYNK_LED_OFF, timeout=5)
            except:
                pass

        cv2.imshow("Security Feed", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    print("\n🛑 System stopped manually.")

finally:
    cap.release()
    cv2.destroyAllWindows()
    print("🔚 System stopped.")
