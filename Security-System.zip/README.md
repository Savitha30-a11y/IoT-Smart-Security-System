# IoT-Based Smart Security System Using Motion Detection and Blynk Cloud

A Python-powered IoT security project that uses your webcam to detect motion in real time. When motion is detected, the system captures an image, triggers a Blynk Cloud alert, and switches an LED indicator ON in the Blynk app.

## Features
- Real-time motion detection using OpenCV  
- Captures and stores images automatically  
- Sends live alerts to Blynk Cloud  
- LED indication and mobile notification  

## Requirements
```
pip install opencv-python requests
```

## Run
```
python main.py
```

Press **q** to stop the camera feed.
